-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : ven. 12 août 2022 à 20:54
-- Version du serveur : 10.4.24-MariaDB
-- Version de PHP : 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `kco`
--

-- --------------------------------------------------------

--
-- Structure de la table `choisir`
--

CREATE TABLE `choisir` (
  `IDCLIENT` char(10) NOT NULL,
  `IDPAYEMENT` char(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `clients`
--

CREATE TABLE `clients` (
  `IDCLIENT` char(10) NOT NULL,
  `PSEUDO` varchar(50) DEFAULT NULL,
  `NOM` varchar(100) DEFAULT NULL,
  `PRENOM` varchar(100) DEFAULT NULL,
  `SEXE` varchar(2) DEFAULT NULL,
  `CONTACT` varchar(14) DEFAULT NULL,
  `EMAIL` varchar(255) DEFAULT NULL,
  `MOTDEPASSE` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `commande`
--

CREATE TABLE `commande` (
  `IDCOMMANDE` char(10) NOT NULL,
  `NAME` text DEFAULT NULL,
  `LASTE` text DEFAULT NULL,
  `ADDRESSES` text DEFAULT NULL,
  `INFO` text DEFAULT NULL,
  `REGIONS` text DEFAULT NULL,
  `VILLE` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `compteclients`
--

CREATE TABLE `compteclients` (
  `IDCOMPT` char(10) NOT NULL,
  `IDCLIENT` char(10) NOT NULL,
  `NOM` text DEFAULT NULL,
  `MDP` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `faire`
--

CREATE TABLE `faire` (
  `IDCLIENT` char(10) NOT NULL,
  `IDCOMMANDE` char(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `jupes`
--

CREATE TABLE `jupes` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` float NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `jupes`
--

INSERT INTO `jupes` (`id`, `name`, `price`) VALUES
(1, 'super confort', 5000),
(2, 'confortable', 6000),
(3, 'plaquer', 7500);

-- --------------------------------------------------------

--
-- Structure de la table `modepayement`
--

CREATE TABLE `modepayement` (
  `IDPAYEMENT` char(10) NOT NULL,
  `MOBILE` text DEFAULT NULL,
  `ESPECE` int(11) DEFAULT NULL,
  `BANCAIRE` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `patlons`
--

CREATE TABLE `patlons` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` float NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `patlons`
--

INSERT INTO `patlons` (`id`, `name`, `price`) VALUES
(1, 'bon haut', 2000),
(2, 'mélanger pagne', 10000);

-- --------------------------------------------------------

--
-- Structure de la table `prod-img`
--

CREATE TABLE `prod-img` (
  `id` int(11) NOT NULL,
  `nom` varchar(50) NOT NULL,
  `taille` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `prix` int(11) NOT NULL,
  `quantite` int(11) NOT NULL,
  `datepub` date NOT NULL,
  `images` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `prod-img`
--

INSERT INTO `prod-img` (`id`, `nom`, `taille`, `type`, `prix`, `quantite`, `datepub`, `images`) VALUES
(6, '014.png', 2815, 'image/png', 0, 1500, '0000-00-00', '2022-08-07'),
(7, '014.png', 2815, 'image/png', 1500, 10, '2022-08-07', 'C:xamp	mpphp48E9.tmp'),
(8, '014.png', 2815, 'image/png', 1500, 10, '2022-08-07', 'C:xamp	mpphpC4A2.tmp'),
(9, 'hackers.png', 380719, 'image/png', 1000, 10, '2022-08-14', 'C:xamp	mpphpDC6C.tmp');

-- --------------------------------------------------------

--
-- Structure de la table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` float NOT NULL DEFAULT 0,
  `category` varchar(255) NOT NULL,
  `size` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `products`
--

INSERT INTO `products` (`id`, `name`, `price`, `category`, `size`) VALUES
(1, 'robe de mariage', 15000, 'image', ''),
(2, 'mini jupe', 10000, 'image', ''),
(3, 'sous vetement', 7000, 'image', ''),
(4, 'robe', 15000, 'image', ''),
(5, 'sexi', 15000, 'sous vetements', ''),
(6, 'volante', 16000, 'sous vetements', ''),
(7, 'jolie', 10000, 'sous vetements', 'S et M'),
(9, 'petite culotte', 14000, 'sous vetements', 'S et M'),
(10, 'petite culotte', 17000, 'sous vetements', 'L'),
(11, 'petite culotte', 20000, 'sous vetements', 'XL'),
(12, 'rb cotn', 15000, 'robes', 'S et M'),
(13, 'rb cotn', 18000, 'robes', 'L'),
(14, 'rb cotn', 22000, 'robes', 'XL'),
(15, 'brode', 20000, 'robes', 'S et M'),
(16, 'brode', 25000, 'robes', 'L'),
(17, 'brode', 35000, 'robes', 'XL'),
(18, 'makeb', 18000, 'robes', 'S et M'),
(19, 'makeb', 23000, 'robes', 'L'),
(20, 'makeb', 26000, 'robes', 'XL'),
(21, '', 8000, 'pantalons', 'S et M'),
(22, '', 10000, 'pantalons', 'XL'),
(23, 'makeb', 15000, 'pantalon', 'XL'),
(24, 'triangle', 15000, 'robes', 'S et M'),
(25, 'triangle', 18000, 'robes', 'L'),
(26, 'triangle', 22000, 'robes', 'XL'),
(27, 'suipe', 14000, 'jupes', 'S et M'),
(28, 'suipe', 17000, 'jupes', 'L'),
(29, 'suipe', 20000, 'jupes', 'XL'),
(30, 'biki', 13000, 'sous vetements', 'S et M'),
(31, 'biki', 14000, 'sous vetements', 'L'),
(32, 'biki', 16000, 'sous vetements', 'XL'),
(33, 'plaqué', 13000, 'robes', 'S et M'),
(34, 'plaqué', 15000, 'robes', 'L'),
(35, 'plaqué', 18000, 'robes', 'XL'),
(36, 'violet', 12000, 'sous vetements', 'S et M'),
(37, 'violet', 14000, 'sous vetements', 'L'),
(38, 'violet', 18000, 'sous vetements', 'XL'),
(41, 'marron', 14000, 'sous vetements', 'S et M'),
(42, 'marron', 16000, 'sous vetements', 'L'),
(43, 'marron', 18000, 'sous vetements', 'XL'),
(44, 'ctn rosé', 17000, 'robes', 'S et M'),
(45, 'ctn rosé', 20000, 'robes', 'L'),
(46, 'ctn rosé', 25000, 'robes', 'XL'),
(47, 'ctn face rouge', 10000, 'jupes', 'S et M'),
(48, 'ctn face rouge', 13000, 'jupes', 'L'),
(49, 'ctn face rouge', 15000, 'jupes', 'XL'),
(53, 'rose transparente ', 12000, 'robes', 'S et M'),
(54, 'rouge transparente ', 15000, 'robes', 'XL'),
(55, 'rouge transparente ', 18000, 'robes', 'L'),
(56, ' bikini', 15000, 'sous vetements', 'XL'),
(57, 'bikini ', 20000, 'sous vetements', 'L'),
(58, 'jaune ctn', 14000, 'sous vetements', 'S et M'),
(59, '', 17000, 'sous vetements', 'XL'),
(60, '', 12000, 'sous vetements', 'S et M'),
(61, '', 15000, 'sous vetements', 'XL'),
(62, '', 18000, 'sous vetements', 'L'),
(63, 'RTS', 25000, 'r_pagne', 'S et M'),
(64, 'RTS', 30000, 'r_pagne', 'XL'),
(65, 'RTS', 35000, 'r_pagne', 'L'),
(66, '', 18000, 'r_pagne', 'S et M'),
(67, '', 23000, 'r_pagne', 'XL'),
(68, '', 26, 'r_pagne', 'L'),
(69, '', 17000, 'r_pagne', 'S et M'),
(70, '', 20000, 'r_pagne', 'XL'),
(71, '', 25000, 'r_pagne', 'L'),
(72, '', 25000, 'r_pagne', 'S et M'),
(73, '', 30000, 'r_pagne', 'XL'),
(74, '', 35000, 'r_pagne', 'L'),
(75, '', 25000, 'r_pagne', 'S et M'),
(76, '', 30000, 'r_pagne', 'XL'),
(77, '', 35000, 'r_pagne', 'XL'),
(78, '', 16000, 'r_pagne', 'S et M'),
(79, '', 20000, 'r_pagne', 'XL'),
(80, '', 25000, 'r_pagne', 'L'),
(81, '', 5000, 'r_pagne', 'S et M'),
(82, '', 6000, 'r_pagne', 'XL'),
(83, '', 8000, 'r_pagne', 'L'),
(84, '', 4000, 'r_pagne', 'S et M'),
(85, '', 5000, 'r_pagne', 'XL'),
(86, '', 12000, 'pantalons', 'L'),
(87, '', 18000, 'pantalons', 'S et M'),
(88, '', 22000, 'pantalons', 'XL'),
(89, '', 26000, 'pantalons', 'L'),
(90, '', 18, 'jupes', 'S et M'),
(91, '', 22000, 'jupes', 'XL'),
(92, '', 26000, 'jupes', 'L');

-- --------------------------------------------------------

--
-- Structure de la table `produits`
--

CREATE TABLE `produits` (
  `IDPRODUITS` int(11) NOT NULL,
  `IDCOMMANDE` char(10) NOT NULL,
  `IDCLIENT` char(10) DEFAULT NULL,
  `LIBPRODUITS` int(11) DEFAULT NULL,
  `PRIXPRODUITS` int(11) DEFAULT NULL,
  `DATAILES` text DEFAULT NULL,
  `DATEPUBLICATION` date DEFAULT NULL,
  `QUANTITEPRODUITS` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `robes`
--

CREATE TABLE `robes` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` float NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `robes`
--

INSERT INTO `robes` (`id`, `name`, `price`) VALUES
(1, 'transparente', 9000),
(2, 'mini', 11000),
(3, 'bras mince', 8000),
(4, 'épaise', 5000);

-- --------------------------------------------------------

--
-- Structure de la table `r_pagne`
--

CREATE TABLE `r_pagne` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` float NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `r_pagne`
--

INSERT INTO `r_pagne` (`id`, `name`, `price`) VALUES
(1, 'robe simple', 8000),
(2, 'makeba', 11000),
(3, 'coté', 10000),
(4, 'fantte', 9000);

-- --------------------------------------------------------

--
-- Structure de la table `sous_vtms`
--

CREATE TABLE `sous_vtms` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` float NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `sous_vtms`
--

INSERT INTO `sous_vtms` (`id`, `name`, `price`) VALUES
(1, 'bikini', 5000),
(2, 'doh vide', 6000);

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `pseudo` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `last` varchar(100) NOT NULL,
  `contact` varchar(14) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mdp` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `pseudo`, `name`, `last`, `contact`, `email`, `mdp`) VALUES
(1, 'konehadou', 'kone', 'hadou', 'kone@gmail.com', '0595640996', '$2y$10$NsJO0q0DaT7H7T3ZdH.efup7ZPQQj9NT.K66ivLDNnb'),
(2, 'konehadou', 'kone', 'hadou', 'kone@gmail.com', '0595640996', '$2y$10$C6vleNUsJyS7WC6xyw4nPO8vY/NKLvns4QHWlN6lOtF'),
(3, 'konehadou', 'kone', 'hadou', 'kone@gmail.com', '0595640996', '$2y$10$SbVsM2w8VmaUAZgG0HjKGuBkZ59ilhMrjdOuAtPTPZ4'),
(4, 'konehadou', 'kone', 'hadou', 'kone@gmail.com', '0595640996', '$2y$10$ZsabeVIy5yr8NtATxKErG.x1XcEWfi.M8KXhmyHinqF');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `choisir`
--
ALTER TABLE `choisir`
  ADD PRIMARY KEY (`IDCLIENT`,`IDPAYEMENT`),
  ADD KEY `FK_CHOISIR2` (`IDPAYEMENT`);

--
-- Index pour la table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`IDCLIENT`);

--
-- Index pour la table `commande`
--
ALTER TABLE `commande`
  ADD PRIMARY KEY (`IDCOMMANDE`);

--
-- Index pour la table `compteclients`
--
ALTER TABLE `compteclients`
  ADD PRIMARY KEY (`IDCOMPT`),
  ADD KEY `FK_AVOIRE` (`IDCLIENT`);

--
-- Index pour la table `faire`
--
ALTER TABLE `faire`
  ADD PRIMARY KEY (`IDCLIENT`,`IDCOMMANDE`),
  ADD KEY `FK_FAIRE2` (`IDCOMMANDE`);

--
-- Index pour la table `jupes`
--
ALTER TABLE `jupes`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `modepayement`
--
ALTER TABLE `modepayement`
  ADD PRIMARY KEY (`IDPAYEMENT`);

--
-- Index pour la table `patlons`
--
ALTER TABLE `patlons`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `prod-img`
--
ALTER TABLE `prod-img`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `produits`
--
ALTER TABLE `produits`
  ADD PRIMARY KEY (`IDPRODUITS`),
  ADD KEY `FK_ACHETER` (`IDCLIENT`),
  ADD KEY `FK_CONTENIR` (`IDCOMMANDE`);

--
-- Index pour la table `robes`
--
ALTER TABLE `robes`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `r_pagne`
--
ALTER TABLE `r_pagne`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `sous_vtms`
--
ALTER TABLE `sous_vtms`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `jupes`
--
ALTER TABLE `jupes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `patlons`
--
ALTER TABLE `patlons`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `prod-img`
--
ALTER TABLE `prod-img`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT pour la table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=93;

--
-- AUTO_INCREMENT pour la table `robes`
--
ALTER TABLE `robes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pour la table `r_pagne`
--
ALTER TABLE `r_pagne`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pour la table `sous_vtms`
--
ALTER TABLE `sous_vtms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `choisir`
--
ALTER TABLE `choisir`
  ADD CONSTRAINT `FK_CHOISIR` FOREIGN KEY (`IDCLIENT`) REFERENCES `clients` (`IDCLIENT`),
  ADD CONSTRAINT `FK_CHOISIR2` FOREIGN KEY (`IDPAYEMENT`) REFERENCES `modepayement` (`IDPAYEMENT`);

--
-- Contraintes pour la table `compteclients`
--
ALTER TABLE `compteclients`
  ADD CONSTRAINT `FK_AVOIRE` FOREIGN KEY (`IDCLIENT`) REFERENCES `clients` (`IDCLIENT`);

--
-- Contraintes pour la table `faire`
--
ALTER TABLE `faire`
  ADD CONSTRAINT `FK_FAIRE` FOREIGN KEY (`IDCLIENT`) REFERENCES `clients` (`IDCLIENT`),
  ADD CONSTRAINT `FK_FAIRE2` FOREIGN KEY (`IDCOMMANDE`) REFERENCES `commande` (`IDCOMMANDE`);

--
-- Contraintes pour la table `produits`
--
ALTER TABLE `produits`
  ADD CONSTRAINT `FK_ACHETER` FOREIGN KEY (`IDCLIENT`) REFERENCES `clients` (`IDCLIENT`),
  ADD CONSTRAINT `FK_CONTENIR` FOREIGN KEY (`IDCOMMANDE`) REFERENCES `commande` (`IDCOMMANDE`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
