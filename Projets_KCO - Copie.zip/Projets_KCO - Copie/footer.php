<!-- footer section start-->



<section class="footer">

<div class="box-container">

    <div class="box">

        <h3> HKserVice <i class="fas fa-shopping-basket"></i></h3>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
        <div class="share">
            <a href="#" class="fab fa-facebook-f"></a>
            <a href="#" class="fab fa-twitter"></a>
            <a href="#" class="fab fa-instagram"></a>
            <a href="#" class="fab fa-linkedin"></a>
            <a href="#" class="fab fa-github"></a>
        </div>

    </div>

    <div class="box">

        <h3> contact info</h3>
        <a href="#" class="links"><i class="fas fa-phone"></i> +225 0595640996</a>
        <a href="#" class="links"><i class="fas fa-phone"></i> +225 0171799397</a>
        <a href="#" class="links"><i class="fas fa-envelope"></i>konehadou0201@gmail.com</a>
        <a href="#" class="links"><i class="fas fa-map-marker-alt"></i> Côte d'Ivoire,cocody, angré</a>

    </div>

    <div class="box">

        <h3> quick links</h3>
        <a href="#" class="links"><i class="fas fa-arrow-right"></i>home</a>
        <a href="#" class="links"><i class="fas fa-arrow-right"></i>features</a>
        <a href="#" class="links"><i class="fas fa-arrow-right"></i>products</a>
        <a href="#" class="links"><i class="fas fa-arrow-right"></i>categories</a>
        <a href="#" class="links"><i class="fas fa-arrow-right"></i>blogs</a>

    </div>

    <div class="box">

        <h3> newsletter</h3>
        <p>subsribe for latest updates</p>
        <div class="hk">
            <input type="email" placeholder="your email" class="email">
            <input type="submit" value="Subscribe" class="btn">
            <img src="image/commande.png" alt="" class="payment-img">
        </div>
    </div>

</div>

<div class="credit"> created by <span>mr. Kone Hadou</span> |all rights reserved</div>

</section>


<!-- footer section ends-->



<!-- swiperjs from cdn link-->

<script src="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.js"></script>

<!-- custume js file link -->
<script lang="javascript" src="JS/script.js"></script>
</body>

</html>