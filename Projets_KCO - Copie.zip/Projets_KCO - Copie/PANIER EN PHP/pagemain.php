<?php   require'header.php'; ?>

<pre>
   <?php 


/*
$req =$DB->db->prepare('SELECT * FROM products');
$req->execute();
var_dump($req->fetchall()); 
*/


?> 
</pre>



    <!-- features section start-->


    <section class="features" id="features">

        <h1 class="heading">our <span>features</span></h1>

        <div class="box-container">
                
            <div class="box">
                <img src="image/features1.JPG" alt="">
                <h3>Simple & Elégant</h3>
                <p>n'hésitez pas clicker pour ci-dessous en savoir plus</p>
                <a href="#" class="btn" id="roi">read more</a>
            </div>


            <div class="box">
                <img src="t_image/57.JPG" alt="">
                <h3>je kiff de wahoo</h3>
                <p>j'aime bien ce modèle mais comment faire, va vite dans products!!</p>
                <a href="#" class="btn">read more</a>
            </div>


            <div class="box">
                <img src="image/features3.JPG" alt="">
                <h3>Super confortable</h3>
                <p>Je veux le même modèle mais avec plus de couleur. tu attend quoi pour nous contacter !!</p>
                <a href="#" class="btn">read more</a>
            </div>

        </div>
    </section>


    <!-- features section end-->


    <!-- produits section start-->



    <section class="products" id="products">


        <h1 class="heading">our <span>products</span></h1>

        <div class="swiper product-slider">

            <div class="swiper-wrapper">

            <?php $products = $DB->query('SELECT * FROM products WHERE category="sous vetements"'); ?>
                <?php foreach($products as $product):  ?>

                    <!-- je met la premiere box dans la boucle foreach           SOUS VETEMENTS  -->

                <div class="swiper-slide box">
                    <!-- je remplace le nom de l'image par l'id de ma base de donnée
                mais d'abord les images sont tous renommer en fonctio de l'id-->
                    <img src="S_vetements/<?=$product->id; ?>.JPG" alt="">
                    <!--<h3>fresh orange</h3> -->
                    <?=" <h3>$product->name</h3> "?>
                     <div class="price">taille :<?= $product->size;?></div>
                    <div class="price"><?= number_format( $product->price,2,',','');  ?> Fcfa</div>
                    <div class="starts">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <!-- je donne le lient en mettant l'id du pruduit qui doit s'afficher     UNE CLASS POURLE BOUTTON SPECIALE
                            JAVASCRIPT
                     -->
                    <a href="addpanier.php?id=<?= $product->id ; ?>" class="btn addPanier">add to cart</a>
                </div>

                    <?php endforeach ?>






            <!--  ici j'ais enlever trois box      sous_vtms -->

            </div>

        </div>

        <!-- copie -->

        <div class="swiper product-slider">

            <div class="swiper-wrapper"> 







            <?php $products = $DB->query('SELECT * FROM products WHERE category="robes";'); ?>
                <?php foreach($products as $product):  ?>

                    <!-- je met la premiere box dans la boucle foreach-->

                <div class="swiper-slide box">
                    <!-- je remplace le nom de l'image par l'id de ma base de donnée
                mais d'abord les images sont tous renommer en fonctio de l'id-->
                    <img src="Robes/<?=$product->id; ?>.JPG" alt="">
                    <!--<h3>fresh orange</h3> -->
                    <?=" <h3>$product->name</h3> "?>
                    <div class="price">taille :<?= $product->size;?></div>
                    <div class="price"><?= number_format( $product->price,2,',','');  ?> Fcfa</div>
                    <div class="starts">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <!-- je donne le lient en mettant l'id du pruduit qui doit s'afficher     UNE CLASS POURLE BOUTTON SPECIALE
                            JAVASCRIPT
                     -->
                    <a href="addpanier.php?id=<?= $product->id ; ?>" class="btn addPanier">add to cart</a>
                </div>

                    <?php endforeach ?>











<!--  #############################################################################################  


                <div class="swiper-slide box">
                    <img src="image/products4.JPG" alt="">
                    <h3>fresh orange</h3>
                    <div class="price"> $4.99/--10.99/-</div>
                    <div class="starts">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <a href="#" class="btn">add to cart</a>
                </div>


                <div class="swiper-slide box">
                    <img src="image/products5.JPG" alt="">
                    <h3>fresh orange</h3>
                    <div class="price"> $4.99/--10.99/-</div>
                    <div class="starts">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <a href="#" class="btn">add to cart</a>
                </div>


                <div class="swiper-slide box">
                    <img src="image/products8.JPG" alt="">
                    <h3>fresh orange</h3>
                    <div class="price"> $4.99/--10.99/-</div>
                    <div class="starts">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <a href="#" class="btn">add to cart</a>
                </div>

                <div class="swiper-slide box">
                    <img src="image/products7.JPG" alt="">
                    <h3>fresh orange</h3>
                    <div class="price"> $4.99/--10.99/-</div>
                    <div class="starts">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <a href="#" class="btn">add to cart</a>
                </div>

                -->


            </div>

        </div>

    </section>

    <!-- ############################### start second copie  ##########################################################################-->

    <section class="products" id="products">

       <!-- <h1 class="heading">our <span>products</span></h1>  -->

            <div class="swiper product-slider">

            <div class="swiper-wrapper"> 







            <?php $products = $DB->query('SELECT * FROM products  WHERE category="r_pagne";'); ?>
                <?php foreach($products as $product):  ?>

                    <!-- je met la premiere box dans la boucle foreach-->

                <div class="swiper-slide box">
                    <!-- je remplace le nom de l'image par l'id de ma base de donnée
                mais d'abord les images sont tous renommer en fonctio de l'id-->
                    <img src="R_pagne/<?=$product->id; ?>.JPG" alt="">
                    <!--<h3>fresh orange</h3> -->
                    <?=" <h3>$product->name</h3> "?>
                     <div class="price">taille :<?= $product->size;?></div>
                    <div class="price"><?= number_format( $product->price,2,',','');  ?> Fcfa</div>
                    <div class="starts">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <!-- je donne le lient en mettant l'id du pruduit qui doit s'afficher     UNE CLASS POURLE BOUTTON SPECIALE
                            JAVASCRIPT
                     -->
                    <a href="addpanier.php?id=<?= $product->id ; ?>" class="btn addPanier">add to cart</a>
                </div>

                    <?php endforeach ?>







                <!--
                <div class="swiper-slide box">
                    <img src="image/products8.JPG" alt="">
                    <h3>fresh orange</h3>
                    <div class="price"> $4.99/--10.99/-</div>
                    <div class="starts">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <a href="#" class="btn">add to cart</a>
                </div>


                <div class="swiper-slide box">
                    <img src="image/products9.JPG" alt="">
                    <h3>fresh orange</h3>
                    <div class="price"> $4.99/--10.99/-</div>
                    <div class="starts">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <a href="#" class="btn">add to cart</a>
                </div>


                <div class="swiper-slide box">
                    <img src="image/products10.JPG" alt="">
                    <h3>fresh orange</h3>
                    <div class="price"> $4.99/--10.99/-</div>
                    <div class="starts">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <a href="#" class="btn">add to cart</a>
                </div>

                <div class="swiper-slide box">
                    <img src="image/products10.JPG" alt="">
                    <h3>fresh orange</h3>
                    <div class="price"> $4.99/--10.99/-</div>
                    <div class="starts">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <a href="#" class="btn">add to cart</a>
                </div>

                -->

            </div>

        </div>





            <div class="swiper product-slider">

            <div class="swiper-wrapper"> 







            <?php $products = $DB->query('SELECT * FROM products WHERE category="pantalons";'); ?>
                <?php foreach($products as $product):  ?>

                    <!-- je met la premiere box dans la boucle foreach-->

                <div class="swiper-slide box">
                    <!-- je remplace le nom de l'image par l'id de ma base de donnée
                mais d'abord les images sont tous renommer en fonctio de l'id-->
                    <img src="A_pantalons/<?=$product->id; ?>.JPG" alt="">
                    <!--<h3>fresh orange</h3> -->
                    <?=" <h3>$product->name</h3> "?>
                    <div class="price">taille :<?= $product->size;?></div>
                    <div class="price"><?= number_format( $product->price,2,',','');  ?> Fcfa</div>
                    <div class="starts">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <!-- je donne le lient en mettant l'id du pruduit qui doit s'afficher     UNE CLASS POURLE BOUTTON SPECIALE
                            JAVASCRIPT
                     -->
                    <a href="addpanier.php?id=<?= $product->id ; ?>" class="btn addPanier">add to cart</a>
                </div>

                    <?php endforeach ?>






        <!-- copie 
        <div class="swiper product-slider">

            <div class="swiper-wrapper">

                <div class="swiper-slide box">
                    <img src="image/products12.JPG" alt="">
                    <h3>fresh orange</h3>
                    <div class="price"> $4.99/--10.99/-</div>
                    <div class="starts">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <a href="#" class="btn">add to cart</a>
                </div>


                <div class="swiper-slide box">
                    <img src="image/products13.JPG" alt="">
                    <h3>fresh orange</h3>
                    <div class="price"> $4.99/--10.99/-</div>
                    <div class="starts">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <a href="#" class="btn">add to cart</a>
                </div>


                <div class="swiper-slide box">
                    <img src="image/products14.JPG" alt="">
                    <h3>fresh orange</h3>
                    <div class="price"> $4.99/--10.99/-</div>
                    <div class="starts">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <a href="#" class="btn">add to cart</a>
                </div>

                <div class="swiper-slide box">
                    <img src="image/products15.JPG" alt="">
                    <h3>fresh orange</h3>
                    <div class="price"> $4.99/--10.99/-</div>
                    <div class="starts">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <a href="#" class="btn">add to cart</a>
                </div>

                -->

            </div>

        </div>

    </section>





    <!-- #############################  end second copy ############################################################################-->


    <!-- ##################################### Troisieme copies  ####################################################################-->


     <section class="products" id="products">

        <!--<h1 class="heading">our <span>products</span></h1>  -->

            <div class="swiper product-slider">

            <div class="swiper-wrapper"> 







            <?php $products = $DB->query('SELECT * FROM products WHERE category="jupes";'); ?>
                <?php foreach($products as $product):  ?>

                    <!-- je met la premiere box dans la boucle foreach-->

                <div class="swiper-slide box">
                    <!-- je remplace le nom de l'image par l'id de ma base de donnée
                mais d'abord les images sont tous renommer en fonctio de l'id-->
                    <img src="A_jupes/<?=$product->id; ?>.JPG" alt="">
                    <!--<h3>fresh orange</h3> -->
                    <?=" <h3>$product->name</h3> "?>
                    <div class="price">taille :<?= $product->size;?></div>
                    <div class="price"><?= number_format( $product->price,2,',','');  ?> Fcfa</div>
                    <div class="starts">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <!-- je donne le lient en mettant l'id du pruduit qui doit s'afficher     UNE CLASS POURLE BOUTTON SPECIALE
                            JAVASCRIPT
                     -->
                    <a href="addpanier.php?id=<?= $product->id ; ?>" class="btn addPanier">add to cart</a>
                </div>

                    <?php endforeach ?>







                <!--
                <div class="swiper-slide box">
                    <img src="image/products8.JPG" alt="">
                    <h3>fresh orange</h3>
                    <div class="price"> $4.99/--10.99/-</div>
                    <div class="starts">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <a href="#" class="btn">add to cart</a>
                </div>


                <div class="swiper-slide box">
                    <img src="image/products9.JPG" alt="">
                    <h3>fresh orange</h3>
                    <div class="price"> $4.99/--10.99/-</div>
                    <div class="starts">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <a href="#" class="btn">add to cart</a>
                </div>


                <div class="swiper-slide box">
                    <img src="image/products10.JPG" alt="">
                    <h3>fresh orange</h3>
                    <div class="price"> $4.99/--10.99/-</div>
                    <div class="starts">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <a href="#" class="btn">add to cart</a>
                </div>

                <div class="swiper-slide box">
                    <img src="image/products10.JPG" alt="">
                    <h3>fresh orange</h3>
                    <div class="price"> $4.99/--10.99/-</div>
                    <div class="starts">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <a href="#" class="btn">add to cart</a>
                </div>

                -->

            </div>

        </div>





            <div class="swiper product-slider">

            <div class="swiper-wrapper"> 







            <?php $products = $DB->query('SELECT * FROM products  WHERE category="robes";'); ?>
                <?php foreach($products as $product):  ?>

                    <!-- je met la premiere box dans la boucle foreach-->

                <div class="swiper-slide box">
                    <!-- je remplace le nom de l'image par l'id de ma base de donnée
                mais d'abord les images sont tous renommer en fonctio de l'id-->
                    <img src="Robes/<?=$product->id; ?>.JPG" alt="">
                    <!--<h3>fresh orange</h3> -->
                    <?=" <h3>$product->name</h3> "?>
                     <div class="price">taille :<?= $product->size;?></div>
                    <div class="price"><?= number_format( $product->price,2,',','');  ?> Fcfa</div>
                    <div class="starts">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <!-- je donne le lient en mettant l'id du pruduit qui doit s'afficher     UNE CLASS POURLE BOUTTON SPECIALE
                            JAVASCRIPT
                     -->
                    <a href="addpanier.php?id=<?= $product->id ; ?>" class="btn addPanier">add to cart</a>
                </div>

                    <?php endforeach ?>






        <!-- copie 
        <div class="swiper product-slider">

            <div class="swiper-wrapper">

                <div class="swiper-slide box">
                    <img src="image/products12.JPG" alt="">
                    <h3>fresh orange</h3>
                    <div class="price"> $4.99/--10.99/-</div>
                    <div class="starts">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <a href="#" class="btn">add to cart</a>
                </div>


                <div class="swiper-slide box">
                    <img src="image/products13.JPG" alt="">
                    <h3>fresh orange</h3>
                    <div class="price"> $4.99/--10.99/-</div>
                    <div class="starts">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <a href="#" class="btn">add to cart</a>
                </div>


                <div class="swiper-slide box">
                    <img src="image/products14.JPG" alt="">
                    <h3>fresh orange</h3>
                    <div class="price"> $4.99/--10.99/-</div>
                    <div class="starts">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <a href="#" class="btn">add to cart</a>
                </div>

                <div class="swiper-slide box">
                    <img src="image/products15.JPG" alt="">
                    <h3>fresh orange</h3>
                    <div class="price"> $4.99/--10.99/-</div>
                    <div class="starts">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <a href="#" class="btn">add to cart</a>
                </div>

                -->

            </div>

        </div>

    </section>


    <!-- ################################ end thirds copy#########################################################################-->

    <!-- produits section ends-->

    <!-- categorie section start-->

    <section class="categorie" id="categorie">


        <h3 class="heading">products <span>categories</span></h3>

        <div class="box-container">

            <div class="box">
                <img src="Robes/25.JPG" alt="">
                <h3>robes ultras jolie</h3>
                <p>upto 45% off</p>
                <a href="#" class="btn"> shop now</a>
            </div>

            <div class="box">
                <img src="S_vetements/37.JPG" alt="">
                <h3>bikini a Volonté</h3>
                <p>upto 45% off</p>
                <a href="#" class="btn"> shop now</a>
            </div>

            <div class="box">
                <img src="R_pagne/78.JPG" alt="">
                <h3>Modèle Simple</h3>
                <p>upto 45% off</p>
                <a href="#" class="btn"> shop now</a>
            </div>

            <div class="box">
                <img src="image/categories4.JPG" alt="">
                <h3>très Confortable</h3>
                <p>upto 45% off</p>
                <a href="#" class="btn"> shop now</a>
            </div>

        </div>

    </section>

    <!-- categorie section ends-->


    <!-- review section start-->

    <section class="review" id="review">

        <h3 class="heading">customer's <span>review</span></h3>

        <div class="swiper review-slider">

            <div class="swiper-wrapper ">

                <div class="swiper-slide box">
                    <img src="image/commande.png" alt="">
                    <p>
                        Frachement dire je valide KcoService vous être le meilleur ,C'est le seul que je connais ou le client commande puis donne ses caracteristiques et en suite il est satisfaire à la livraison ...! 

                    </p>
                    <h3>Christine</h3>
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                </div>


                <div class="swiper-slide box">
                    <img src="image/commande2.png" alt="">
                    <p>
                        Vous être tres attentif au clients ,et cela me va droit au coeur ,vraiment continuer dans cette logique et c'est sûr que vous fairez bientôt partie des meilleurs ..! 

                    </p>
                    <h3>florance</h3>
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                </div>

                <div class="swiper-slide box">
                    <img src="image/commande.png" alt="">
                    <p>
                        vous être superbe KcoService vous avez tous mes encourragements ..!

                    </p>
                    <h3>john deo</h3>
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                </div>


                <div class="swiper-slide box">
                    <img src="image/commande2.png" alt="">
                    <p>
                         Un grand merci toutec ceux qui n'hesite pas à commanter et nous complimenter merci ausi de faire nous faire part de vos idées pour que ensemble nous progrèssons ....

                    </p>
                    <h3>KcoService!</h3>
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                </div>

            </div>

        </div>

    </section>

    <!-- review section ends-->



    <!-- blogs section start-->



    <section class="blogs" id="blogs">

        <h1 class="heading">our <span>blogs</span></h1>

        <div class="box-container">

            <div class="box">

                <img src="S_vetements/2.JPG" alt="">
                <div class="content">
                    <div class="icons">
                        <a href="#"><i class="fas fa-user"></i>by user</a>
                        <a href="#"><i class="fas fa-user"></i> 1st Août, 2022 </a>

                    </div>
                    <h3>Le plus beau parmis les meilleurs</h3>
                    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, voluptates?</p>
                    <a href="#" class="btn">read more</a>
                </div>
            </div>

            <div class="box">

                <img src="image/commande2.png" alt="">
                <div class="content">
                    <div class="icons">
                        <a href="#"><i class="fas fa-user"></i>by user</a>
                        <a href="#"><i class="fas fa-user"></i> 1st Août, 2022 </a>

                    </div>
                    <h3>Mon Afrique et ses merveilles</h3>
                    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, voluptates?</p>
                    <a href="#" class="btn">read more</a>
                </div>
            </div>

            <div class="box">

                <img src="image/commande.png" alt="">
                <div class="content">
                    <div class="icons">
                        <a href="#"><i class="fas fa-user"></i>by user</a>
                        <a href="#"><i class="fas fa-user"></i> 1st Août, 2022 </a>
                    </div>

                    <h3>J'ais faire mon choix</h3>
                    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, voluptates?</p>
                    <a href="#" class="btn">read more</a>
                </div>
            </div>

        </div>

    </section>



    <!-- blogs section ends-->

<?php  require'footer.php'; ?>

    