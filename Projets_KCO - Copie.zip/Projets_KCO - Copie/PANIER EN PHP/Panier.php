<?php require'header.php'; ?>

<?php  //var_dump($_SESSION);  ?>

<?php 
/* 
    if(isset($_GET['del'])){
        $panier ->del($_GET['del']);
    }  
    */  
?>

<section class="panier">

    <div class="shopping-cart">
                            
    <?php  

        $ids= array_keys($_SESSION['panier']);
        //var_dump($ids);
        if(empty($ids)){ $products =array();
        }else{ 
            $products =$DB->query('SELECT * FROM products WHERE id IN (' .implode(',',$ids).')   ');
            }
        foreach($products as $product):

    ?> 


    <div class="box">

            <a href="panier.php?delPanier=<?= $product->id; ?>"><i class="fas fa-trash"></i></a>
            <img src="t_image/<?= $product->id; ?>.JPG" alt="">

            <div class="content">

                <?=" <h3>$product->name</h3> "?>
                <span class="price"><?= number_format( $product->price,2,',','');  ?> Fcfa</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <span class="quantity">Qty :   <?php echo $_SESSION['panier'][$product->id];  ?></span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <span class="quantity">Taille :   <?= $product->size;?></span>
                <div class="price"></div>

            </div>
    </div>

        <?php endforeach; ?>


                                <!--
                            <div class="box">
                                <i class="fas fa-trash"></i>
                                <img src="image/commande2.png" alt="">
                                <div class="content">
                                    <h3>le meilleurs</h3>
                                    <span class="price">$4.99</span>
                                    <span class="quantity">qty : 1</span>
                                </div>
                            </div>


                            <div class="box">
                                <i class="fas fa-trash"></i>
                                <img src="image/commande.png" alt="">
                                <div class="content">
                                    <h3>le meilleur</h3>
                                    <span class="price">$4.99</span>
                                    <span class="quantity">qty : 1</span>
                                </div>
                            </div>
                             -->

<div class="total">total : <?= number_format($panier->total(),2,',',' ');  ?>   Fcfa </div>
                            <a href="#" class="btn">checkout</a>
                        </div>
                   
 


</section>


<!-- Pour le panier -->                            
                       

<style>


.panier .shopping-cart{
    position:block;
    top: 110%;
    right: 2rem; /* on met à -110% pour faire le javaScript  par defaut c'est 2rem */
    padding: 1rem;
    border-radius: .5rem;
    box-shadow: var(--box-shadow);
    width: 129rem;
    background: #fff;
}
/* apres le code js  */
.panier .shopping-cart.is-active{
    right: 2rem auto;
    transition: .4s linear;

/*  finish   */

}
.panier .shopping-cart .box{
    display: flex;
    align-items: center;
    gap: 1rem;
    position: relative;
    margin: 1rem;
}

.panier .shopping-cart .box img{
    height: 10rem;
}

.panier .shopping-cart .box .fa-trash{
    font-size: 2rem;
    position: absolute;
    top: 50%;
    right: 2rem;
    cursor: pointer;
    color: var(--light-color);
    transform: translateY(-50%);
}

.panier .shopping-cart .box .fa-trash:hover{
    color: var(--orange);
}

.panier .shopping-cart .box .content h3{
    color: var(--black);
    font-size: 1.7rem;
    padding-bottom: 1rem;
}

.panier .shopping-cart .box .content span{
    color: var(--light-color);
    font-size: 1.6rem;
}

.panier .shopping-cart .box .content .quantity{
    padding-left: 1rem;
}

.panier .shopping-cart .total{
    font-size: 2.5rem;
    padding: 1rem 0;
    text-align: center;
    color: var(--black);
}

.panier .shopping-cart .btn{
    display: block;
    text-align: center;
    margin: 1rem;
}



@media (max-width: 450px) {

    .panier .shopping-cart{
        width: 100%;
     }
   
    .shopping-cart .btn{
        width: 40%;
    }
}



</style>

<?php require'footer.php'; ?>