<?php require'action/ActionForms.php';  ?>
<?php require'header.php'; ?>
<!-- sinup section start--> 
<section class="sinup">

    <div class="container">

        <form class="create-login-form" method="POST">
        
            <h3>create account now</h3>
            <?php 
            if(isset($erreurMSG)){

                echo '<p>'.$erreurMSG.'</p>';
            }  
            ?>
            <input type="text" name="Pseudo" placeholder="Pseudo name" class="box" autocomplete="off"  style="width:73% ;"><br>
            <input type="text" name="name" placeholder="First Name :" class="box" autocomplete="off" > 
            <input type="text" name="last" placeholder="Laste Name"class="box" autocomplete="off" ><br>
            <!--<input type="text" name="sexe" placeholder="sexe" class="box" autocomplete="off" required>-->
            <input type="text" name="contact" placeholder="phone number" class="box" autocomplete="off" ><br>
            <input type="email" name="email" placeholder="email address" class="box" autocomplete="off" >
            <input type="password" name="mdp" placeholder="password" class="box" autocomplete="off"> <br>
            <input type="submit" name="submit" value="Submit">
                <p class="fas fa-user" id="snp-btn" style="cursor: pointer;">login now </p>
             <?php 
            if(isset($erreurMSG)){

                echo '<p style="color:red;">'.$erreurMSG.'</p>';
            }  
            ?>
        
        </form>

    </div>

     <form action="" method="POST" class="login-forms">
            <h3>login now</h3>
            <input type="email" placeholder=" your email" class="box">
            <input type="password" placeholder="your password" class="box">
            <p>forget your password <a href="#">click here</a></p>
            <p>don't have an account<a href="sinup.php" target="_blank">create now</a></p>
            <input type="submit" value="login now" class="btn">
        </form>



<style type="text/css">
    

@media (max-width: 450px) {

    .sinup{
        position: relative;
        width: 85%;
        margin: 5rem 4rem;
        background: rd;
        background-position: center;

     }
      .sinup .container{
        position: absolute;
        top: -12%;
        left: 1.5rem;
        width: 35rem;
        background: ;
        height: 59rem;
      }
     .sinup .container .create-login-form{

    padding-top: 1rem 2rem;
    height: 63rem; 

}

.sinup .container .create-login-form button{
     position: sticky;;
    top: 200%;
    right: 0%;
    text-align: center;
    background: #fff;
    color: #130f40;
}
.sinup .container .create-login-form p{
    position: absolute;
    top: 103rem;
    right: 110rem;
}

}
.sinup .container .create-login-form button{
   position: absolute;
   top: 100rem;
   right: 70rem;
}

.sinup .container .create-login-form p{
    position: absolute;
    top: 102rem;
    right: 120rem;
}















/* pour le formulaire de connexion */

.sinup .login-forms{
    position: absolute;
    display: none;
    top: 70%;
    right: 3rem;     /* 2rem; */
    width: 55rem;
    box-shadow: var(--box-shadow);
    border-radius: .5rem;
    padding: 2rem;
    background: #fff;
    text-align: center;

}

/* Pour le js  */
.sinup .login-forms.is-active{
    display: block;
    right: 70rem;
    transition: all .3s linear;
}


/*  finish  */

.sinup .login-forms h3{
    font: 2.5rem;
    text-transform: uppercase;
    color: var(--black);
}
.sinup .login-forms .box{
    width: 100%;
    margin: .7rem 0;
    background: #fff;
    border-radius: .5rem;
    padding: 1rem;
    font-size: 1.6rem;
    color: var(--black);
    text-transform: none;
}

.sinup .login-forms p{
    font-size: 1.4rem;
    padding: .5rem 0;
    color: var(--light-color);
}
.sinup .login-forms p a{
    color: var(--orange);
    text-decoration: underline;
}




</style>
</section>


<!-- sinup section ends--> 
<?php require'footer.php';  ?>
