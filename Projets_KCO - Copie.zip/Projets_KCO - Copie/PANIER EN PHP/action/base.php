<?php
try{
	$con =new PDO("mysql:host=localhost;dbname=kco",'root','');
}catch(PDOException $e){
	die("erreu de connexion".$e->getMessage());
}


