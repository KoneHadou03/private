<?php
require'base.php';

if(isset($_POST['submit'])){

    if(!empty($_POST['Pseudo']) AND !empty( $_POST['name']) AND !empty($_POST['last']) AND !empty($_POST['email']) AND !empty($_POST['mdp']) AND !empty( $_POST['contact'])){

        $user_pseudo =htmlspecialchars($_POST['Pseudo']);
        $user_name =htmlspecialchars($_POST['name']);
        $user_lastname =htmlspecialchars($_POST['last']);
        $user_email =htmlspecialchars($_POST['email']);
        $user_number =htmlspecialchars($_POST['contact']);
        $user_password =password_hash($_POST['mdp'], PASSWORD_DEFAULT);

        $UserExiste =$con->prepare('SELECT email FROM users WHERE email=? AND mdp=?');
        $UserExiste ->execute(array($user_email,$user_password));

        if($UserExiste->rowCount()== 0){

            $InsertUser = $con->prepare('INSERT INTO users(pseudo,name,last,contact,email,mdp) VALUES(?,?,?,?,?,?)');
            $InsertUser ->execute(array($user_pseudo, $user_name,$user_lastname,  $user_email,$user_number,$user_password));

                // authentification

                $InfoUser =$con->prepare('SELECT id,name,last,email,contact FROM users WHERE  name= ? AND last=? AND email=? AND contact=?');
                /*
                 $InfoUser->execute(array($user_name,$user_lastname,$user_email,$user_number));

                 $InfoRecup =$InfoUser->fetch();

                 $_SESSION['auth']=true;
                 $_SESSION['id']=$InfoRecup['id'];
                 $_SESSION['name']=$InfoRecup['name'];
                 $_SESSION['last']=$InfoRecup['last'];
                 $_SESSION['email']=$InfoRecup['email'];
                 $_SESSION['contact']=$InfoRecup['contact'];

                 header('location:pagemain.php');
                 */

        }else{
            echo"cet utlisateur existe déja sur le site";
        }
    }else{
        $erreurMSG ="SVP veillez completer tous les champs !";
    }
}


