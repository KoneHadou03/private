<?php
require '_header.php';



?><!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>site Hkservice</title>
    <!--font awesome cdn link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css">

    <!-- swiperjs from cdn link -->

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.css" />

    <!-- custum css file link -->
    <link rel="stylesheet" href="../CSS/style.css">
    <link rel="stylesheet" href="../CSS/style-snp.css">
</head>

<body>

    <!-- Header Section start -->

    <header class="header">

        <a href="pagemain.php" class="logo"> <i class="fas fa-shopping-basket"> </i>HKserVice</a>

        <nav class="navbar">
            <a href="pagemain.php">home</a>
            <a href="#features">features</a>
            <a href="#products">products</a>
            <a href="#categorie">categories</a>
            <a href="#review">review</a>
            <a href="#blogs">blogs</a>
        </nav>

        <!-- pour les icons-->
        <div class="icons">
            <div class="fas fa-bars" id="menu-btn"></div>
            <div class="fas fa-search" id="search-btn"></div>
            <a href="panier.php">
                <div class="fas fa-shopping-cart" id="cart-btn">
                    <span id="count" 
                    style="
                    position: absolute;
                    top: 1%;
                    font-size: 1.5rem;
                    color:orange;


                    ">.<?= $panier->count(); ?></span>
                </div>
            </a>
            <div class="fas fa-user" id="login-btn"></div>

        </div>

        <!-- pour la bar de recherche -->
        <form action="" class="search-form">
            <input type="search" placeholder="search here..." id="search-box">
            <label for="search-box" class="fas fa-search"></label>
        </form>

        <!-- Pour le panier -->
        <form action="" method="POST"> 
                                    
                                <div class="shopping-cart">
                                    <!--
                                    <div class="box">
                                        <i class="fas fa-trash"></i>
                                        <img src="image/commande.png" alt="">
                                        <div class="content">
                                            <h3>le meilleur</h3>
                                            <span class="price">$4.99</span>
                                            <span class="quantity">qty : 1</span>
                                        </div>
                                    </div>
         ################################################################################################################################### -->
                                    <?php  

                                    $ids= array_keys($_SESSION['panier']);
                                    if(empty($ids)){
                                        $products =array();
                                    }else{
                                    $products =$DB->query('SELECT * FROM products WHERE id IN (' .implode(',',$ids).')   ');
                                    }
                                    foreach($products as $product):

                                    ?> 


                                    <div class="box">
                                        <i class="fas fa-trash"></i>
                                        <img src="image/commande2.png" alt="">
                                        <div class="content">
                                            <h3>le meilleurs</h3>
                                            <span class="price"><?= number_format( $product->price,2,',','');  ?> Fcfa</span>
                                            <span class="quantity">qty : 1</span>
                                        </div>
                                    </div>
                                     <?php endforeach; ?>


                                        <!--      

                                    <div class="box">
                                        <i class="fas fa-trash"></i>
                                        <img src="image/commande.png" alt="">
                                        <div class="content">
                                            <h3>le meilleur</h3>
                                            <span class="price">$4.99</span>
                                            <span class="quantity">qty : 1</span>
                                        </div>
                                    </div>

                                    -->

                                    <div class="total"> total : $19.69/-</div>
                                    <a href="#" class="btn">checkout</a>
                                </div>

       
        </form>


        <form action="../Action/loginform.php" method="POST" class="login-form">
            <h3>login now</h3>
            <input type="email" placeholder=" your email" class="box">
            <input type="password" placeholder="your password" class="box">
            <p>forget your password <a href="#">click here</a></p>
            <p>don't have an account<a href="sinup.php" target="_blank">create now</a></p>
            <input type="submit" value="login now" class="btn">
        </form>
    </header>



    <!-- Header Section end -->


    <!-- home section starts-->

    <section class="home" id="home">

        <div class="content">
            <h3> Kco service le<span>Crochet </span>en Or </h3>
            <p>
                Le service est ouvert 24h/24, toujours disponible. Alors qu'est-ce que tu attend pour passé ta commande et
                KcoService te faire livré dans un bref délair 100% garantir !! 
            </p>
            <a href="#" class="btn">shop now</a>
        </div>


    </section>


    <!-- home section ends -->