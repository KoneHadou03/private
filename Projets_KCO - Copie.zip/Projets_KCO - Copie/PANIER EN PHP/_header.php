<?php
require 'db.class.php';
require 'panier.class.php';
// initialisation de la variable DB
$DB =new DB();
$panier =new panier($DB);


?>