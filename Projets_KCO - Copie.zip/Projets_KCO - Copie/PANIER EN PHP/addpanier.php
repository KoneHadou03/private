<?php
require '_header.php';
$json = array('error' => true);
if(isset($_GET['id'])){
 $product= $DB->query('SELECT id FROM products WHERE id=:id', array('id' => $_GET['id']));
 //var_dump($product);
 
    if(empty($product)){
    $json['message'] =  "Ce produits n'existe pas" ; 
  } 
     //var_dump($product);
    //$_SESSION['panier'][$product[0]->id] =1;
    
    $panier->add($product[0]->id);
    $json['error'] = false;
    $json['total'] = $panier->total();
    $json['count'] = $panier->count();
    $json['message']="le produit a bien été ajouter à votre panier ";
}else{
    $json['message'] ="Vous n'avez pas selectionné de produit à ajouter au panier";
}
echo json_encode($json);
