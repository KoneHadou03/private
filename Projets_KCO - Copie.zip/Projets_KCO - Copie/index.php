<?php   require'header.php'; ?>

    <!-- features section start-->


    <section class="features" id="features">

        <h1 class="heading">our <span>features</span></h1>

        <div class="box-container">

            <div class="box">
                <img src="image/features1.JPG" alt="">
                <h3>fresh and organic</h3>
                <p>votre satisfaction set notre priorité le client est roi</p>
                <a href="#" class="btn" id="roi">read more</a>
            </div>

            <style>
                .features .box-container form {
                    position: absolute;
                    background: #000;
                    color: #fff;
                    height: 50rem;
                    left: -1000rem;
                    width: 60rem;
                    border-radius: .5rem;
                }
                
                .features .box-container form.Active {
                    left: 50rems;
                }
            </style>

            <form action="" class="menu">
                <h4>c'est du bon</h4>
                <input type="text" placeholder="c'est bon " class="ssc">
            </form>


            <div class="box">
                <img src="image/features2.JPG" alt="">
                <h3>fresh and organic</h3>
                <p>votre satisfaction set notre priorité le client est roi</p>
                <a href="#" class="btn">read more</a>
            </div>


            <div class="box">
                <img src="image/features3.JPG" alt="">
                <h3>fresh and organic</h3>
                <p>votre satisfaction set notre priorité le client est roi</p>
                <a href="#" class="btn">read more</a>
            </div>

        </div>
    </section>


    <!-- features section end-->



    <!-- produits section start-->



    <section class="products" id="products">


        <h1 class="heading">our <span>products</span></h1>

        <div class="swiper product-slider">

            <div class="swiper-wrapper">

                <div class="swiper-slide box">
                    <img src="image/prodcts1.JPG" alt="">
                    <h3>fresh orange</h3>
                    <div class="price"> $4.99/--10.99/-</div>
                    <div class="starts">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <a href="#" class="btn">add to cart</a>
                </div>


                <div class="swiper-slide box">
                    <img src="image/prodcts1.JPG" alt="">
                    <h3>fresh orange</h3>
                    <div class="price"> $4.99/--10.99/-</div>
                    <div class="starts">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <a href="#" class="btn">add to cart</a>
                </div>


                <div class="swiper-slide box">
                    <img src="image/products2.JPG" alt="">
                    <h3>fresh orange</h3>
                    <div class="price"> $4.99/--10.99/-</div>
                    <div class="starts">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <a href="#" class="btn">add to cart</a>
                </div>

                <div class="swiper-slide box">
                    <img src="image/products3.JPG" alt="">
                    <h3>fresh orange</h3>
                    <div class="price"> $4.99/--10.99/-</div>
                    <div class="starts">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <a href="#" class="btn">add to cart</a>
                </div>

            </div>

        </div>

        <!-- copie -->

        <div class="swiper product-slider">

            <div class="swiper-wrapper">

                <div class="swiper-slide box">
                    <img src="image/products4.JPG" alt="">
                    <h3>fresh orange</h3>
                    <div class="price"> $4.99/--10.99/-</div>
                    <div class="starts">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <a href="#" class="btn">add to cart</a>
                </div>


                <div class="swiper-slide box">
                    <img src="image/products5.JPG" alt="">
                    <h3>fresh orange</h3>
                    <div class="price"> $4.99/--10.99/-</div>
                    <div class="starts">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <a href="#" class="btn">add to cart</a>
                </div>


                <div class="swiper-slide box">
                    <img src="image/products6.JPG" alt="">
                    <h3>fresh orange</h3>
                    <div class="price"> $4.99/--10.99/-</div>
                    <div class="starts">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <a href="#" class="btn">add to cart</a>
                </div>

                <div class="swiper-slide box">
                    <img src="image/products7.JPG" alt="">
                    <h3>fresh orange</h3>
                    <div class="price"> $4.99/--10.99/-</div>
                    <div class="starts">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <a href="#" class="btn">add to cart</a>
                </div>

            </div>

        </div>

    </section>

    <!-- ############################### start second copie ##########################################################################-->

    <section class="products" id="products">


        <!--<h1 class="heading">our <span>products</span></h1>-->

        <div class="swiper product-slider">

            <div class="swiper-wrapper">

                <div class="swiper-slide box">
                    <img src="image/products8.JPG" alt="">
                    <h3>fresh orange</h3>
                    <div class="price"> $4.99/--10.99/-</div>
                    <div class="starts">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <a href="#" class="btn">add to cart</a>
                </div>


                <div class="swiper-slide box">
                    <img src="image/products9.JPG" alt="">
                    <h3>fresh orange</h3>
                    <div class="price"> $4.99/--10.99/-</div>
                    <div class="starts">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <a href="#" class="btn">add to cart</a>
                </div>


                <div class="swiper-slide box">
                    <img src="image/products10.JPG" alt="">
                    <h3>fresh orange</h3>
                    <div class="price"> $4.99/--10.99/-</div>
                    <div class="starts">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <a href="#" class="btn">add to cart</a>
                </div>

                <div class="swiper-slide box">
                    <img src="image/products11.JPG" alt="">
                    <h3>fresh orange</h3>
                    <div class="price"> $4.99/--10.99/-</div>
                    <div class="starts">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <a href="#" class="btn">add to cart</a>
                </div>

            </div>

        </div>

        <!-- copie -->

        <div class="swiper product-slider">

            <div class="swiper-wrapper">

                <div class="swiper-slide box">
                    <img src="image/products12.JPG" alt="">
                    <h3>fresh orange</h3>
                    <div class="price"> $4.99/--10.99/-</div>
                    <div class="starts">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <a href="#" class="btn">add to cart</a>
                </div>


                <div class="swiper-slide box">
                    <img src="image/products13.JPG" alt="">
                    <h3>fresh orange</h3>
                    <div class="price"> $4.99/--10.99/-</div>
                    <div class="starts">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <a href="#" class="btn">add to cart</a>
                </div>


                <div class="swiper-slide box">
                    <img src="image/products14.JPG" alt="">
                    <h3>fresh orange</h3>
                    <div class="price"> $4.99/--10.99/-</div>
                    <div class="starts">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <a href="#" class="btn">add to cart</a>
                </div>

                <div class="swiper-slide box">
                    <img src="image/products15.JPG" alt="">
                    <h3>fresh orange</h3>
                    <div class="price"> $4.99/--10.99/-</div>
                    <div class="starts">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <a href="#" class="btn">add to cart</a>
                </div>

            </div>

        </div>

    </section>

    <!-- #############################  end second copy ############################################################################-->


    <!-- ##################################### Troisieme copies  ####################################################################-->


    <section class="products" id="products">


        <!--<h1 class="heading">our <span>products</span></h1>-->

        <div class="swiper product-slider">

            <div class="swiper-wrapper">

                <div class="swiper-slide box">
                    <img src="image/products16.JPG" alt="">
                    <h3>fresh orange</h3>
                    <div class="price"> $4.99/--10.99/-</div>
                    <div class="starts">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <a href="#" class="btn">add to cart</a>
                </div>


                <div class="swiper-slide box">
                    <img src="image/products17.JPG" alt="">
                    <h3>fresh orange</h3>
                    <div class="price"> $4.99/--10.99/-</div>
                    <div class="starts">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <a href="#" class="btn">add to cart</a>
                </div>


                <div class="swiper-slide box">
                    <img src="image/products18.JPG" alt="">
                    <h3>fresh orange</h3>
                    <div class="price"> $4.99/--10.99/-</div>
                    <div class="starts">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <a href="#" class="btn">add to cart</a>
                </div>

                <div class="swiper-slide box">
                    <img src="image/commande2.png" alt="">
                    <h3>fresh orange</h3>
                    <div class="price"> $4.99/--10.99/-</div>
                    <div class="starts">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <a href="#" class="btn">add to cart</a>
                </div>

            </div>

        </div>

        <!-- copie -->

        <div class="swiper product-slider">

            <div class="swiper-wrapper">

                <div class="swiper-slide box">
                    <img src="image/commande2.png" alt="">
                    <h3>fresh orange</h3>
                    <div class="price"> $4.99/--10.99/-</div>
                    <div class="starts">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <a href="#" class="btn">add to cart</a>
                </div>


                <div class="swiper-slide box">
                    <img src="image/commande.png" alt="">
                    <h3>fresh orange</h3>
                    <div class="price"> $4.99/--10.99/-</div>
                    <div class="starts">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <a href="#" class="btn">add to cart</a>
                </div>


                <div class="swiper-slide box">
                    <img src="image/commande2.png" alt="">
                    <h3>fresh orange</h3>
                    <div class="price"> $4.99/--10.99/-</div>
                    <div class="starts">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <a href="#" class="btn">add to cart</a>
                </div>

                <div class="swiper-slide box">
                    <img src="image/commande.png" alt="">
                    <h3>fresh orange</h3>
                    <div class="price"> $4.99/--10.99/-</div>
                    <div class="starts">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <a href="#" class="btn">add to cart</a>
                </div>

            </div>

        </div>

    </section>


    <!-- ################################ end thirds copy#########################################################################-->

    <!-- produits section ends-->

    <!-- categorie section start-->

    <section class="categorie" id="categorie">


        <h3 class="heading">products <span>categories</span></h3>

        <div class="box-container">

            <div class="box">
                <img src="image/categories1.JPG" alt="">
                <h3>vegitable</h3>
                <p>upto 45% off</p>
                <a href="#" class="btn"> shop now</a>
            </div>

            <div class="box">
                <img src="image/categories2.JPG" alt="">
                <h3>vegitable</h3>
                <p>upto 45% off</p>
                <a href="#" class="btn"> shop now</a>
            </div>

            <div class="box">
                <img src="image/categories3.JPG" alt="">
                <h3>vegitable</h3>
                <p>upto 45% off</p>
                <a href="#" class="btn"> shop now</a>
            </div>

            <div class="box">
                <img src="image/categories4.JPG" alt="">
                <h3>vegitable</h3>
                <p>upto 45% off</p>
                <a href="#" class="btn"> shop now</a>
            </div>

        </div>

    </section>

    <!-- categorie section ends-->


    <!-- review section start-->

    <section class="review" id="review">

        <h3 class="heading">customer's <span>review</span></h3>

        <div class="swiper review-slider">

            <div class="swiper-wrapper ">

                <div class="swiper-slide box">
                    <img src="image/commande.png" alt="">
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eligendi exercitationem nostrum quisquam, consequuntur repellat magnam assumenda, suscipit dolore tempora vitae quo mollitia. Pariatur magnam fugiat ea sit, tempore culpa dolore?</p>
                    <h3>john deo</h3>
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                </div>


                <div class="swiper-slide box">
                    <img src="image/commande2.png" alt="">
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eligendi exercitationem nostrum quisquam, consequuntur repellat magnam assumenda, suscipit dolore tempora vitae quo mollitia. Pariatur magnam fugiat ea sit, tempore culpa dolore?</p>
                    <h3>john deo</h3>
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                </div>

                <div class="swiper-slide box">
                    <img src="image/commande.png" alt="">
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eligendi exercitationem nostrum quisquam, consequuntur repellat magnam assumenda, suscipit dolore tempora vitae quo mollitia. Pariatur magnam fugiat ea sit, tempore culpa dolore?</p>
                    <h3>john deo</h3>
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                </div>


                <div class="swiper-slide box">
                    <img src="image/commande2.png" alt="">
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eligendi exercitationem nostrum quisquam, consequuntur repellat magnam assumenda, suscipit dolore tempora vitae quo mollitia. Pariatur magnam fugiat ea sit, tempore culpa dolore?</p>
                    <h3>john deo</h3>
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                </div>

            </div>

        </div>

    </section>

    <!-- review section ends-->



    <!-- blogs section start-->



    <section class="blogs" id="blogs">

        <h1 class="heading">our <span>blogs</span></h1>

        <div class="box-container">

            <div class="box">

                <img src="image/commande.png" alt="">
                <div class="content">
                    <div class="icons">
                        <a href="#"><i class="fas fa-user"></i>by user</a>
                        <a href="#"><i class="fas fa-user"></i> 1st Août, 2022 </a>

                    </div>
                    <h3>fres and organic vegitable and fruits</h3>
                    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, voluptates?</p>
                    <a href="#" class="btn">read more</a>
                </div>
            </div>

            <div class="box">

                <img src="image/commande2.png" alt="">
                <div class="content">
                    <div class="icons">
                        <a href="#"><i class="fas fa-user"></i>by user</a>
                        <a href="#"><i class="fas fa-user"></i> 1st Août, 2022 </a>

                    </div>
                    <h3>fres and organic vegitable and fruits</h3>
                    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, voluptates?</p>
                    <a href="#" class="btn">read more</a>
                </div>
            </div>

            <div class="box">

                <img src="image/commande.png" alt="">
                <div class="content">
                    <div class="icons">
                        <a href="#"><i class="fas fa-user"></i>by user</a>
                        <a href="#"><i class="fas fa-user"></i> 1st Août, 2022 </a>
                    </div>

                    <h3>fres and organic vegitable and fruits</h3>
                    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, voluptates?</p>
                    <a href="#" class="btn">read more</a>
                </div>
            </div>

        </div>

    </section>



    <!-- blogs section ends-->

<?php  require'footer.php'; ?>

    