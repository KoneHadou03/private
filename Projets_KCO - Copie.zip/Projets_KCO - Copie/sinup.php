<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>signup</title>
        <!--font awesome cdn link -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css">
    
        <!-- swiperjs from cdn link -->
    
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.css"/>
    
        <!-- custum css file link -->
        <link rel="stylesheet" href="CSS/style.css">
        <link rel="stylesheet" href="CSS/style-snp.css">
    </head>
<body>
    
<!-- Header Section start -->

<header class="header">

    <a href="#" class="logo"> <i class="fas fa-shopping-basket"> </i>HKserVice</a>

    <nav class="navbar">
        <a href="#home">home</a>
        <a href="index.html" target="#features">features</a>
        <a href="index.html" rget="#products">products</a>
        <a href="#categorie">categories</a>
        <a href="#review">review</a>
        <a href="#blogs">blogs</a>
    </nav>

    <!-- pour les icons-->
    <div class="icons">
        <div class="fas fa-bars" id="menu-btn"></div>
        <div class="fas fa-search" id="search-btn"></div>
          <!--<div class="fas fa-shopping-cart" id="cart-btn"></div>  -->
        <div class="fas fa-user" id="login-btn"></div>
    </div>

    <!-- pour la bar de recherche -->
    <form action="" class="search-form">
        <input type="search" placeholder="search here..." id="search-box">
        <label for="search-box" class="fas fa-search"></label>
    </form>

    <!-- Pour le panier -->
    <div class="shopping-cart">
        <div class="box">
            <i class="fas fa-trash"></i>
            <img src="image/commande.png" alt="">
            <div class="content">
                <h3>le meilleur</h3>
                <span class="price">$4.99</span>
                <span class="quantity">qty : 1</span>
            </div>
        </div>

        <div class="box">
            <i class="fas fa-trash"></i>
            <img src="image/commande2.png" alt="">
            <div class="content">
                <h3>le meilleurs</h3>
                <span class="price">$4.99</span>
                <span class="quantity">qty : 1</span>
            </div>
        </div>


        <div class="box">
            <i class="fas fa-trash"></i>
            <img src="image/commande.png" alt="">
            <div class="content">
                <h3>le meilleur</h3>
                <span class="price">$4.99</span>
                <span class="quantity">qty : 1</span>
            </div>
        </div>

        <div class="total"> total : $19.69/-</div>
        <a href="#" class="btn">checkout</a>
    </div>


    <form action="" class="login-form">
        <h3>login now</h3>
        <input type="email" placeholder=" your email" class="box">
        <input type="password" placeholder="your password" class="box">
        <p>forget your password <a href="#" >click here</a></p>
        <p>don't have an account<a href="sinup.html" target="_blank">create now</a></p>
        <input type="submit" value="login now" class="btn">
    </form>

</header>



 <!-- Header Section end -->

<!-- home section starts-->

<section class="home" id="home">

    <div class="content">
        <h3> fresh and <span>product </span>for your </h3>
        <p>Syntaxe : nomelement Exemple : input permettra de cibler n'importe quel élément
            . Ce sélecteur simple permet de cibler les éléments en fonction de la valeur de leur attribut class . Syntaxe : . nomclasse Exemple </p>
        <a href="#" class="btn">shop now</a>
    </div>


</section>


<!-- home section ends -->


<!-- sinup section start--> 


<section class="sinup">

    <div class="container">

        <form action="" class="create-login-form" method=""">
        
            <h3>create account now</h3>
            <input type="text" placeholder="Pseudo name" class="box" style="width:73% ;"><br>
            <input type="text" placeholder="First Name :" class="box"> 
            <input type="text" placeholder="Laste Name"class="box"><br>
            <input type="text" placeholder="sexe" class="box">
            <input type="text" placeholder="phone number" class="box"><br>
            <input type="email" placeholder="email address" class="box">
            <input type="password" placeholder="password" class="box"> <br>
            <p>i have an account <a href="index.html" class=""">login now</a></p>
            <button value="create" class="btn">Sign In</button>
    
        </form>

    </div>

</section>


<!-- sinup section ends--> 


<!-- footer section start--> 



<section class="footer">

    <div class="box-container">

        <div class="box">

            <h3> HKserVice <i class="fas fa-shopping-basket"></i></h3>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
            <div class="share">
                <a href="#" class="fab fa-facebook-f"></a>
                <a href="#" class="fab fa-twitter"></a>
                <a href="#" class="fab fa-instagram"></a>
                <a href="#" class="fab fa-linkedin"></a>
                <a href="#" class="fab fa-github"></a>
            </div>

        </div>

        <div class="box">

            <h3> contact info</h3>
            <a href="#" class="links"><i class="fas fa-phone"></i> +225 0595640996</a>
            <a href="#" class="links"><i class="fas fa-phone"></i> +225 0171799397</a>
            <a href="#" class="links"><i class="fas fa-envelope"></i>konehadou0201@gmail.com</a>
            <a href="#" class="links"><i class="fas fa-map-marker-alt"></i> Côte d'Ivoire,cocody, angré</a>

        </div>

        <div class="box">

            <h3> quick links</h3>
            <a href="#" class="links"><i class="fas fa-arrow-right"></i>home</a>
            <a href="#" class="links"><i class="fas fa-arrow-right"></i>features</a>
            <a href="#" class="links"><i class="fas fa-arrow-right"></i>products</a>
            <a href="#" class="links"><i class="fas fa-arrow-right"></i>categories</a>
            <a href="#" class="links"><i class="fas fa-arrow-right"></i>blogs</a>
            
        </div>

        <div class="box">

            <h3> newsletter</h3>
            <p>subsribe for latest updates</p>
            <div class="hk">
            <input type="email" placeholder="your email" class="email">
            <input type="submit" value="Subscribe" class="btn">
            <img src="image/commande.png" alt="" class="payment-img">
        </div>
        </div>

    </div>

    <div class="credit"> created by <span>mr. Kone Hadou</span> |all rights reserved</div>

</section>


<!-- footer section ends--> 
<script src="JS/script.js"></script>       

</body>
</html>