<?php


include("../Action/db.php");

$req = "SELECT * FROM `prod-img`";
$resultats =mysqli_query($db,$req);

if($resultats){
    while($row = mysqli_fetch_assoc($resultats)){
        $identifiant = $row['id'];
        $nom = $row['nom'];
    }
}




?>