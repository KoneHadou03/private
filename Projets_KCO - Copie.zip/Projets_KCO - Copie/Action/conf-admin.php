<?php

include ('db.php');

if(isset($submit)){

   $nom =$_FILES['img']['name'];
   $taille =$_FILES['img']['size'];
   $type =$_FILES['img']['type'];
   $images_lui_meme =$_FILES['img']['tmp_name'];
   $prix = $_POST['prix'];
   $quantiter = $_POST['Quantiter'];
   $details = $_POST['detaille'];
   $date = $_POST['date'];
   $submit = $_POST['submit'];

   $req =" INSERT INTO `prod-img`(`id`, `nom`, `taille`, `type`, `images`, `prix`, `quantite`, `datepub`) 
   VALUES ('[value-1]','$nom','$taille','$type','$images_lui_meme','$prix','$quantiter','$date')";

   $result = mysqli_query($database, $req);
   if($result){
      echo" ajouter avec success";
   }else{
      echo "echec hadou";
   }
}