<?php

try{
    $conn= new PDO("mysql:host=localhost;dbname=Projets_vente",'root','');
}catch(PDOException $e){
    echo "echec de connexion". $e->getMessage();
}