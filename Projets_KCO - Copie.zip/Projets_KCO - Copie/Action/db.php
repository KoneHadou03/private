<?php  
    $db =mysqli_connect('localhost','root','','kco') or die('echec');
?>