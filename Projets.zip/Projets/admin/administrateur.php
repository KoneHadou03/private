<?php

var_dump($_FILES);

/*
if(isset($_POST['send'])){
    include ('db.php');
   $nom =$_FILES['img']['name'];
   $taille =$_FILES['img']['size'];
   $type =$_FILES['img']['type'];
   $images_lui_meme =file_get_contents($_FILES['img']['tmp_name']);
   $prix = $_POST['prix'];
   $quantiter = $_POST['Quantiter'];
   $details = $_POST['detaille'];
   $date = $_POST['date'];
   $submit = $_POST['submit'];

   $req =" INSERT INTO `PRODUITS_IMAGES` (`id`, `nom`, `taille`, `type`, `image`, `prix`, `quantite`, `detaille`, `datepublication`) 
   VALUES ('?','$nom ',' $taille',' $type','$images_lui_meme',' $prix ','$quantiter ','$details','  $date')";

   $result = mysqli_query($database, $req);
   if($result){
      echo" ajouter avec success";
   }else{
      echo "echec hadou";
   }
}
*/

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>administrateur</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.css"/>

</head>
<body>

    <div class="container">
        <?php  if(isset($_POST['send'])){
               $nom =$_FILES['img']['name'];
               $taille =$_FILES['img']['size'];
               $type =$_FILES['img']['type'];

            include("base.php");
            $req =$pdo->prepare("insert into Projets_vente(nom,taille,type,image) values(?,?,?,?)");
            $req ->execute(array($nom,$taille,$type));
            
        }
 ?>
   
        <form action="" method="POST" class="admin" enctype="multipart/form-data">
            <h3>la place administrateur </h3>

            <label for="">Images <span>*</span></label> <input type="file" name="img"><br>
            <label for="prix">Prix produits <span>*</span></label> <input type="number" name="prix"><br>
            <label for="detaille">Quantiter <span>*</span></label> <input type="number" name="Quantiter"><br>
                    
            <label for="detaille">Details <span>*</span></label> <input type="text" class="dtls" name="detaille"><br>
                    
            <label for="detaille">Date publications <span>*</span></label> <input type="date" name="date">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <input type="submit" name="send" value="Submit" class="btn">
                    

        </form>

    </div>
    
    <style>

@import url('https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400&display=swap');

/*  Declaration de variable de couleur */

:root{
    --orange:#ff7800;
    --black:#130f40;
    --light-color:#666;
    --box-shadow:0.5rem 1.5rem rgba(0,0,0,.1);
    --border:.2rem solid rgba(0,0,0,.1);
    --outline:.1rem solid rgba(0,0,0,.1);
    --outline-hover:.2rem solid var(--black);
}
        
*{
    font-family:'Poppins';
    list-style: none;
    box-sizing: border-box;
    margin: 0;
    padding: 0;
    text-decoration: none;
    transition: .5s linear;
}
html{
    font-size:62.5%;
    overflow-x: hidden;
    scroll-behavior: smooth;
    scroll-padding-top: 7rem;
}

.container {
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: #eee;
}

.container .admin{
    background-color:#fff;
    margin: 10rem 2rem;
    height: 45rem;
    width: 80rem;
    box-shadow: var(--box-shadow);
    border-radius: .7rem;
    text-align: center;
}
.container .admin h3{
    margin-bottom: 2rem;
    font-size: 1.6rem;
    text-transform: uppercase;
}
.container .admin label{
    font-size:1.4rem ;
}
    
.container .admin label span{
    font-size:1.4rem ;
    color: red;
}
.container .admin input{
    margin-bottom: 2.5rem;
    margin-left: 1rem;
    font-size: 2rem;
    border-radius: .5rem;
    border: none;
    border-left: .3rem solid var(--light-color);
    border-bottom: .3rem solid var(--light-color);
}

.btn{
    background: greenyellow;
    font-size: .2rem;
    color: var(--black);
    border: none;
    border-radius: 10rem;
    width: 10rem;
    cursor: pointer;

}
.dtls{
    height: 10rem;
}

    </style>
</body>
</html>