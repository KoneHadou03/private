<?php

    $con = mysqli_connect('localhost','root','','ex') or die("Could not connect to");

?>