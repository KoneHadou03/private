<?php

$database =new myslqi("localhost","root","", "Projets_vente") or die("Couldn't connect to");


